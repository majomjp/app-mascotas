var firebaseConfig = {
    apiKey: "AIzaSyApLWQkOS8z4RlpNVcBUPVzShN6gIKdz7c",
    authDomain: "app-gestion-58baf.firebaseapp.com",
    databaseURL: "https://app-gestion-58baf.firebaseio.com",
    projectId: "app-gestion-58baf",
    storageBucket: "app-gestion-58baf.appspot.com",
    messagingSenderId: "892243443996",
    appId: "1:892243443996:web:928d1fc2fbe5e26c783ad9",
    measurementId: "G-21QFPGX5XK"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();